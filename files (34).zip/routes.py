import os
from flask import Blueprint, render_template, redirect, url_for, request, flash, send_from_directory, current_app, send_file
from flask_login import login_user, logout_user, login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from extensions import db
from models import User, Question, Category, QuestionUsage
from datetime import datetime
from io import BytesIO
from docx import Document
from docx.shared import Pt, Inches, RGBColor

main = Blueprint('main', __name__)

def is_admin():
    return current_user.is_authenticated and current_user.role == "admin"

@main.route('/')
def index():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    return render_template('index.html')

@main.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('main.dashboard'))
        flash('Email ou senha incorretos.', 'danger')
    return render_template('login.html')

@main.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@main.route('/dashboard')
@login_required
def dashboard():
    if is_admin():
        questions = Question.query.all()
        return render_template('dashboard_admin.html', questions=questions)
    else:
        categories = Category.query.all()
        selected_category = request.args.get('category', type=int)
        category_id = selected_category if selected_category else None
        questions = Question.query.filter_by(category_id=category_id) if category_id else Question.query
        questions = questions.all()
        return render_template('dashboard_professor.html', questions=questions, categories=categories, selected_category=category_id)

@main.route('/users')
@login_required
def users():
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    users = User.query.all()
    return render_template('users.html', users=users)

@main.route('/users/new', methods=['GET', 'POST'])
@login_required
def add_user():
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        role = request.form['role']
        if User.query.filter_by(email=email).first():
            flash('Email já cadastrado.', 'danger')
            return redirect(url_for('main.add_user'))
        user = User(
            name=name,
            email=email,
            password_hash=generate_password_hash(password),
            role=role
        )
        db.session.add(user)
        db.session.commit()
        flash('Usuário criado!', 'success')
        return redirect(url_for('main.users'))
    return render_template('user_form.html')

@main.route('/users/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    user = User.query.get_or_404(user_id)
    if user.role == 'admin':
        flash('Não é possível deletar o usuário administrador.', 'danger')
        return redirect(url_for('main.users'))
    db.session.delete(user)
    db.session.commit()
    flash('Usuário removido.', 'success')
    return redirect(url_for('main.users'))

@main.route('/categories')
@login_required
def categories():
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    categories = Category.query.all()
    return render_template('categories.html', categories=categories)

@main.route('/categories/new', methods=['GET', 'POST'])
@login_required
def add_category():
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    if request.method == 'POST':
        name = request.form['name']
        if Category.query.filter_by(name=name).first():
            flash('Categoria já existe.', 'danger')
            return redirect(url_for('main.add_category'))
        db.session.add(Category(name=name))
        db.session.commit()
        flash('Categoria criada!', 'success')
        return redirect(url_for('main.categories'))
    return render_template('category_form.html')

@main.route('/categories/delete/<int:category_id>', methods=['POST'])
@login_required
def delete_category(category_id):
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    category = Category.query.get_or_404(category_id)
    db.session.delete(category)
    db.session.commit()
    flash('Categoria removida.', 'success')
    return redirect(url_for('main.categories'))

@main.route('/questions/new', methods=['GET', 'POST'])
@login_required
def add_question():
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    categories = Category.query.all()
    if request.method == 'POST':
        statement = request.form['statement']
        option_a = request.form['option_a']
        option_b = request.form['option_b']
        option_c = request.form['option_c']
        option_d = request.form['option_d']
        option_e = request.form['option_e']
        correct_option = request.form['correct_option']
        category_id = request.form['category_id']
        image = request.files.get('image')
        image_filename = None
        if image and image.filename:
            filename = secure_filename(image.filename)
            upload_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
            os.makedirs(current_app.config['UPLOAD_FOLDER'], exist_ok=True)
            image.save(upload_path)
            image_filename = filename
        question = Question(
            statement=statement,
            option_a=option_a,
            option_b=option_b,
            option_c=option_c,
            option_d=option_d,
            option_e=option_e,
            correct_option=correct_option,
            image_filename=image_filename,
            category_id=category_id,
            created_by=current_user.id
        )
        db.session.add(question)
        db.session.commit()
        flash('Questão criada!', 'success')
        return redirect(url_for('main.dashboard'))
    return render_template('question_form.html', categories=categories)

@main.route('/questions/delete/<int:question_id>', methods=['POST'])
@login_required
def delete_question(question_id):
    if not is_admin():
        flash('Acesso negado.', 'danger')
        return redirect(url_for('main.dashboard'))
    question = Question.query.get_or_404(question_id)
    if question.image_filename:
        image_path = os.path.join(current_app.config['UPLOAD_FOLDER'], question.image_filename)
        if os.path.exists(image_path):
            os.remove(image_path)
    db.session.delete(question)
    db.session.commit()
    flash('Questão removida.', 'success')
    return redirect(url_for('main.dashboard'))

@main.route('/questions/use/<int:question_id>', methods=['POST'])
@login_required
def use_question(question_id):
    if is_admin():
        flash('Ação não permitida para admin.', 'danger')
        return redirect(url_for('main.dashboard'))
    stage = request.form.get('stage', '')
    usage = QuestionUsage(
        question_id=question_id,
        professor_id=current_user.id,
        used_at=datetime.utcnow(),
        stage=stage
    )
    db.session.add(usage)
    db.session.commit()
    flash('Uso da questão registrado!', 'success')
    return redirect(url_for('main.dashboard'))

@main.route('/questions/<int:question_id>')
@login_required
def question_detail(question_id):
    question = Question.query.get_or_404(question_id)
    usages = QuestionUsage.query.filter_by(question_id=question_id).all()
    return render_template('question_detail.html', question=question, usages=usages)

@main.route('/questions/<int:question_id>/export')
@login_required
def export_question_docx(question_id):
    question = Question.query.get_or_404(question_id)
    document = Document()

    # Título e categoria
    document.add_heading('ENEM - Questão de Inglês', 0)
    document.add_paragraph(f'Categoria: {question.category.name}', style='Intense Quote')

    document.add_paragraph('Enunciado:', style='Heading 2')
    document.add_paragraph(question.statement, style='Normal')

    # Imagem, se houver
    if question.image_filename:
        img_path = os.path.join(current_app.config['UPLOAD_FOLDER'], question.image_filename)
        if os.path.exists(img_path):
            document.add_picture(img_path, width=Inches(4.5))

    document.add_paragraph('Alternativas:', style='Heading 2')
    options = [
        ('A', question.option_a),
        ('B', question.option_b),
        ('C', question.option_c),
        ('D', question.option_d),
        ('E', question.option_e)
    ]
    for letter, text in options:
        par = document.add_paragraph()
        run = par.add_run(f'{letter}) {text}')
        if letter == question.correct_option:
            run.bold = True
            run.font.color.rgb = RGBColor(0, 128, 0)  # Verde

    document.add_paragraph('')
    document.add_paragraph('________________________________________', style='Normal')
    document.add_paragraph('')

    file_stream = BytesIO()
    document.save(file_stream)
    file_stream.seek(0)
    filename = f"questao_{question.id}.docx"
    return send_file(file_stream, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document')

@main.route('/questions/export_multiple', methods=['POST'])
@login_required
def export_multiple_questions_docx():
    ids = request.form.getlist('question_ids')
    if not ids:
        flash('Nenhuma questão selecionada para exportar.', 'warning')
        return redirect(url_for('main.dashboard'))
    questions = Question.query.filter(Question.id.in_(ids)).all()
    document = Document()
    for idx, question in enumerate(questions, 1):
        document.add_heading(f'Questão {idx}', level=1)
        document.add_paragraph(f'Categoria: {question.category.name}', style='Intense Quote')
        document.add_paragraph('Enunciado:', style='Heading 2')
        document.add_paragraph(question.statement, style='Normal')
        if question.image_filename:
            img_path = os.path.join(current_app.config['UPLOAD_FOLDER'], question.image_filename)
            if os.path.exists(img_path):
                document.add_picture(img_path, width=Inches(4.5))
        document.add_paragraph('Alternativas:', style='Heading 2')
        options = [
            ('A', question.option_a),
            ('B', question.option_b),
            ('C', question.option_c),
            ('D', question.option_d),
            ('E', question.option_e)
        ]
        for letter, text in options:
            par = document.add_paragraph()
            run = par.add_run(f'{letter}) {text}')
            if letter == question.correct_option:
                run.bold = True
                run.font.color.rgb = RGBColor(0, 128, 0)
        document.add_paragraph('')
        document.add_paragraph('________________________________________', style='Normal')
        document.add_paragraph('')
    file_stream = BytesIO()
    document.save(file_stream)
    file_stream.seek(0)
    filename = f"questoes_selecionadas.docx"
    return send_file(file_stream, as_attachment=True, download_name=filename, mimetype='application/vnd.openxmlformats-officedocument.wordprocessingml.document')

@main.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(current_app.config['UPLOAD_FOLDER'], filename)