import os
from flask import Flask
from extensions import db, login_manager

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'troque-por-uma-chave-secreta'
    app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
    app.config['UPLOAD_FOLDER'] = os.path.join('static', 'uploads')
    app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024  # 8MB

    db.init_app(app)
    login_manager.init_app(app)
    login_manager.login_view = 'login'

    with app.app_context():
        from models import User, Question, Category, QuestionUsage
        db.create_all()
        # Cria usuário admin inicial se não existir
        if not User.query.filter_by(email='admin@admin.com').first():
            from werkzeug.security import generate_password_hash
            admin = User(
                name='Administrador',
                email='admin@admin.com',
                password_hash=generate_password_hash('admin123'),
                role='admin'
            )
            db.session.add(admin)
            db.session.commit()
        # Cria categorias padrão se não existirem
        default_cats = ['Música', 'Charge', 'Jornalístico', 'Literário', 'Publicidade', 'Quadrinhos']
        for cat in default_cats:
            if not Category.query.filter_by(name=cat).first():
                db.session.add(Category(name=cat))
        db.session.commit()

        @login_manager.user_loader
        def load_user(user_id):
            return User.query.get(int(user_id))

    from routes import main as main_blueprint
    app.register_blueprint(main_blueprint)

    return app

if __name__ == "__main__":
    app = create_app()
    app.run(debug=True)